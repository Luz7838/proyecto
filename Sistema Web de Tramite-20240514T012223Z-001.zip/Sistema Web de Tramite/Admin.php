<!DOCTYPE html>
<html>
<head>
  <title>Trámites Enviados</title>
  <style>
    body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: block;
            height: 100vh;
        }
        .encabezado{
            display:flex;          
            background-color: red;
            width: 1200px;
            margin:0 auto;
            padding: 5px 0;
        }
        img{
            width: 80px;
            height: 80px;
            padding: 0 10px;
        }
        .encabezado h2{
            color:white;
            padding: 0 10px;
        }
        .navbar {
      overflow: hidden;
      background-color: red;
      display: flex;
      width: 1200px;
      margin:0 auto;
      align-items: stretch; /* Hace que los elementos ocupen toda la altura del contenedor */
    }

    .navbar a,
    #openModalBtn {
      display: flex;
      background-color: red;
      align-items: center;     
      color: white;
      text-align: center;
      text-decoration: none;
      padding: 20px;
      width: 20%;
      margin: 0; /* Elimina cualquier margen que pueda existir */
    }
    .navbar a:hover{
        background-color: #fff;
        color:black;
    }
    .contenedor_general{
        width: 1200px;
        margin:0 auto;
        background-color: #fff;
    }
    .contenedor_tabla{
      

    }
    table{
    border-collapse: collapse;
    box-shadow: 0 5px 10px #B2BABB;
    background-color: white;
    text-align: left;
    overflow: hidden;
    margin:0 auto;
    }
    thead {
      box-shadow: 0 5px 10px #B2BABB;
    }
    th{
      padding: 1rem 2rem;
      text-transform: uppercase;
      letter-spacing: 0.1rem;
      font-size: 0.7rem;
      font-weight: 900;
    }
    td{
      padding: 1rem 2rem;
    }
    td a{
      text-decoration: none;
      color:#5499C7;
    }
    /* Estilos del Modal */
.modal {
    display: none; /* Oculto por defecto */
    position: fixed; /* Fijo en pantalla */
    z-index: 1; /* En el frente */
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto; /* Habilitar scroll si es necesario */
    background-color: rgb(0, 0, 0); /* Fallback color */
    background-color: rgba(0, 0, 0, 0.4); /* Color con opacidad */
}

/* Contenido del Modal */
.modal-content {
    background-color: #fefefe;
    margin: 15% auto; /* 15% desde el top y centrado horizontalmente */
    padding: 20px;
    border: 1px solid #888;
    width: 30%; /* Ancho */
}
.modal-content h2{
    text-align: center;
}
form{
    display: flex;
    flex-direction: column;
    gap: 5px;
    width: 100%;
    padding: 10px;
}
input, label{
    margin-left:15px;
}
input{
    width: 500px;
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
}
/* Botón de cierre */
.closeBtn {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.closeBtn:hover,
.closeBtn:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}

  </style>
  <!-- Estilos -->
</head>
<body>
<div class="encabezado">
        <img src="logoMuni.png" alt="">
        <h2>TRAMITES DE LA MUNICIPALIDAD DE SANTA CRUZ DE FLORES</h1>
</div>
<div class="navbar">
  <a href="Trabajo.php">INICIO</a>
  <p id="openModalBtn">Crear Nuevo Usuario</p>
</div>
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="closeBtn">&times;</span>
            <h2>Crear Nuevo Usuario</h2>
            <form action="guardar_usuario.php" method="post">
            <label for="nombre">Nombre y Apellidos:</label>
            <input type="text" id="nombre" name="nombre" required><br>
            <label for="usuario">Usuario:</label>
            <input type="text" id="usuario" name="usuario" required><br>
            <label for="password">Contraseña:</label>
            <input type="text" id="password" name="password" required><br>
            <input type="submit" value="Enviar">
        </div>
    </div>

  <div class="contenedor_general">
  <div>
    <div class="contenedor_tabla">
    <h2>TRAMITES NUEVOS</h2>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sistemawebtramite";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $sql = "SELECT codigo_tramite, nombre, fecha_envio, correo FROM tabla_tramite WHERE estado = 'enviado'";
    $result = $conn->query($sql);

    echo "<br><table>";
    echo "<thead><tr><th>Código de Trámite</th><th>Nombre</th><th>Fecha de envío</th><th>Correo Electrónico</th></tr></thead>";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tbody>";
            echo "<tr>";
            echo "<td><a href='detalle_tramite.php?codigo=" . $row["codigo_tramite"] . "'>" . $row["codigo_tramite"] . "</a></td>";
            echo "<td>" . $row["nombre"] . "</td>";
            echo "<td>" . $row["fecha_envio"] . "</td>";
            echo "<td>" . $row["correo"] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No se encontraron trámites con estado 'Enviado'.</td></tr>";
    }
    echo "</tbody>";
    echo "</table>";
    ?>
    </div>
    <div>
      <h2>TRAMITES RECHAZADOS</h2>
      <?php
      $sql = "SELECT codigo_tramite, nombre, fecha_envio, correo FROM tabla_tramite WHERE estado = 'rechazado'";
      $result = $conn->query($sql);
  
      echo "<table>";
      echo "<thead><tr><th>Código de Trámite</th><th>Nombre</th><th>Fecha de envío</th><th>Correo Electrónico</th></tr></thead>";
  
      if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo "<tbody>";
              echo "<tr>";
              echo "<td>". $row["codigo_tramite"] . "</a></td>";
              echo "<td>" . $row["nombre"] . "</td>";
              echo "<td>" . $row["fecha_envio"] . "</td>";
              echo "<td>" . $row["correo"] . "</td>";
              echo "</tr>";
          }
      } else {
          echo "<tr><td>No se encontraron trámites con estado 'Enviado'.</td></tr>";
      }
      echo "</tbody>";
      echo "</table>";
      ?>
    </div>
  </div>
  <div>
  <h2>Trámites Recepcionado</h2>
  <?php
      $sql = "SELECT codigo_tramite, nombre, fecha_envio, correo FROM tabla_tramite WHERE estado = 'RECEPCIONADO'";
      $result = $conn->query($sql);
  
      echo "<br><table>";
      echo "<thead><tr><th>Código de Trámite</th><th>Nombre</th><th>Fecha de envío</th><th>Correo Electrónico</th></tr></thead>";
  
      if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo "<tr>";
              echo "<td>". $row["codigo_tramite"] . "</a></td>";
              echo "<td>" . $row["nombre"] . "</td>";
              echo "<td>" . $row["fecha_envio"] . "</td>";
              echo "<td>" . $row["correo"] . "</td>";
              echo "</tr>";
          }
      } else {
          echo "<tr><td colspan='4'>No se encontraron trámites con estado 'RECEPCIONADO'.</td></tr>";
      }
      echo "</table>";
      ?>
  </div>
  <?php
    $conn->close();
    ?>
    <script>
        // Obtener el modal
var modal = document.getElementById("myModal");

// Obtener el botón que abre el modal
var btn = document.getElementById("openModalBtn");

// Obtener el elemento <span> que cierra el modal
var span = document.getElementsByClassName("closeBtn")[0];

// Cuando el usuario haga clic en el botón, abrir el modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// Cuando el usuario haga clic en <span> (x), cerrar el modal
span.onclick = function() {
    modal.style.display = "none";
}

// Cuando el usuario haga clic en cualquier lugar fuera del modal, cerrarlo
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

    </script>
</body>
</html>

