<?php
// Conexión a la base de datos (reemplaza con tus propias credenciales)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistemawebtramite";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Carpeta destino para los PDF (en la raíz del proyecto)
$carpeta_destino = __DIR__ . "/PDF/";

// Recibir datos del formulario
$nombre = $_POST['nombre'];
$correo = $_POST['correo']; // Agregado para recibir el correo
$celular = $_POST['celular']; // Agregado para recibir el número de celular
$codigo_tramite = date("YmdHis"); // Año, mes, día, hora, minutos y segundos
$fecha_envio = date("Y-m-d H:i:s");
$mensaje = "Su FUT se ha enviado con éxito a la mesa de partes"; // Mensaje por defecto

// Verificar errores en la subida del archivo
if ($_FILES['archivo']['error'] !== UPLOAD_ERR_OK) {
    echo "Error al subir el archivo. Código: " . $_FILES['archivo']['error'];
    exit; // Salir del script si hay un error
}

$archivo_nombre = $_FILES['archivo']['name'];
$archivo_temporal = $_FILES['archivo']['tmp_name'];
$archivo_destino = $carpeta_destino . $archivo_nombre;

// Mover el archivo a la carpeta destino
if (move_uploaded_file($archivo_temporal, $archivo_destino)) {
    // Insertar datos en la base de datos
    $estado = "ENVIADO"; // Valor por defecto para el campo 'estado'

    $sql = "INSERT INTO tabla_tramite (nombre, correo, celular, codigo_tramite, fecha_envio, archivo, estado, mensaje) VALUES ('$nombre', '$correo', '$celular', '$codigo_tramite', '$fecha_envio', '$archivo_destino', '$estado', '$mensaje')";

    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("Datos guardados correctamente. Código de trámite: ' . $codigo_tramite . '"); window.location.href = "index.php";</script>';
        exit;
    } else {
        echo '<script>alert("Error al guardar en la base de datos: ' . $conn->error . '"); window.location.href = "index.php";</script>';
    }      
} else {
    echo "Error al mover el archivo a la carpeta destino.";
}

// Cerrar la conexión
$conn->close();
?>
