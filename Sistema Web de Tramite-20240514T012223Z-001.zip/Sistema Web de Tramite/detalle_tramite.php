<!DOCTYPE html>
<html>
<head>
    <title>Detalle del Trámite</title>
    <style>
    body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: block;
            height: 100vh;
        }
        .encabezado{
            display:flex;
            background-color: red;
            width: 1200px;
            margin:0 auto;
            padding: 5px 0;
        }
        img{
            width: 80px;
            height: 80px;
            padding: 0 10px;
        }
        .encabezado h2{
            color:white;
            padding: 0 10px;
        }
        .navbar {
      overflow: hidden;
      background-color: red;
      display: flex;
      width: 1200px;
      margin:0 auto;
      align-items: stretch; /* Hace que los elementos ocupen toda la altura del contenedor */
    }

    .navbar a {
      display: flex;
      background-color: red;
      align-items: center;
      border-radius:5px;
      color: white;
      text-align: center;
      text-decoration: none;
      padding: 20px;
      width: 20%;
      margin: 0; /* Elimina cualquier margen que pueda existir */
    }
    .navbar a:hover{
        background-color: #fff;
        color:black;
    }
    .contenedor_general{
        width: 1200px;
        margin:0 auto;
        background-color: #fff;
        padding: 10px 0;
    }
    .contenedor2{
        width: 80%;
            margin: auto;
            background-color: #f9f9f9;
            padding: 20px;
            border:1px solid black;
            border-radius: 8px;
            
    }
    .contenedor_general h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .contenedor_general p {
            margin-bottom: 10px;
        }

        .contenedor_general a {
            text-decoration: none;
            color: blue;
        }

        .contenedor_general a:hover {
            text-decoration: underline;
        }

        .contenedor_general form input[type='submit'] {
            padding: 8px 16px;
            margin-right: 10px;
            border-radius: 4px;
            border: none;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <!-- Encabezado y navegación -->
    <div class="encabezado">
        <img src="logoMuni.png" alt="">
        <h2>TRAMITES DE LA MUNICIPALIDAD DE SANTA CRUZ DE FLORES</h1>
</div>
<div class="navbar">
  <a href="Trabajo.php">INICIO</a>
  
</div>
    <div class="contenedor_general">
        <div class="contenedor2">
        <h2>Detalle del Trámite</h2>

        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "sistemawebtramite";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Verificar si se ha proporcionado un código de trámite en la URL
        if (isset($_GET['codigo'])) {
            $codigo_tramite = $_GET['codigo'];

            // Realizar la consulta para obtener los detalles del trámite con el código proporcionado
            $sql = "SELECT * FROM tabla_tramite WHERE codigo_tramite = '$codigo_tramite'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                // Mostrar los detalles del trámite
                echo "<p><strong>Código de Trámite:</strong> " . $row["codigo_tramite"] . "</p>";
                echo "<p><strong>Nombre:</strong> " . $row["nombre"] . "</p>";
                echo "<p><strong>Fecha de envío:</strong> " . $row["fecha_envio"] . "</p>";
                echo "<p><strong>Correo Electrónico:</strong> " . $row["correo"] . "</p>";
                
                // Enlace al archivo guardado
                $archivo = $row["archivo"];
                echo "<p><strong>Archivo:</strong> <a href='descarga.php?nombre_archivo=" . urlencode($archivo) . "'><i class='fas fa-download'></i> Descargar archivo</a></p>";
                // Botones para cambiar el estado
                echo "<form action='actualizar_estado.php' method='post'>";
                
                // Nuevo campo de texto (textarea) para el mensaje
                echo "<label for='mensaje'><strong>Mensaje:</strong></label>";
                echo "<textarea id='mensaje' name='mensaje' style='padding: 8px; border-radius: 4px; border: 1px solid #ccc; width: 100%; min-height: 200px; margin-bottom: 10px; resize: vertical;' placeholder='Escribe tu mensaje aquí'></textarea>";

                
                echo "<input type='hidden' name='codigo_tramite' value='" . $row["codigo_tramite"] . "'>";
                echo "<button type='submit' name='subsanar' style='padding: 8px 16px; border-radius: 4px; border: none; background-color: #ffc107; color: black; margin-left: 10px; transition: background-color 0.3s;'> <i class='fas fa-exclamation-triangle'></i> Subsanar</button>";
                // Botón Recepcionar con estilo verde y un ícono de check
                echo "<button type='submit' name='recepcionado' style='padding: 8px 16px; border-radius: 4px; border: none; background-color: #28a745; color: white; transition: background-color 0.3s;'> <i class='fas fa-check'></i> Recepcionar</button>";

                // Botón Rechazar con estilo rojo y un ícono de cruz
                echo "<button type='submit' name='rechazado' style='padding: 8px 16px; border-radius: 4px; border: none; background-color: #dc3545; color: white; margin-left: 10px; transition: background-color 0.3s;'> <i class='fas fa-times'></i> Rechazar</button>";
                echo "</form>";

                // ... otros campos que desees mostrar ...
            } else {
                echo "No se encontró el trámite especificado.";
            }
        } else {
            echo "No se proporcionó un código de trámite.";
        }

        $conn->close();
        ?>
        </div>
        
    </div>
</body>
</html>


