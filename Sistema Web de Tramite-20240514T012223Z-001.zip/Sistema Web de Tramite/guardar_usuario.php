<?php
// Datos de la conexión a la base de datos
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "sistemawebtramite";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del formulario
$nombre = $_POST['nombre'];
$usuario = $_POST['usuario'];
$password = $_POST['password'];

// Hashear la contraseña
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Preparar y enlazar
$stmt = $conn->prepare("INSERT INTO usuarios (nombre, username, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nombre, $usuario, $hashed_password);

// Ejecutar la consulta y verificar el resultado
if ($stmt->execute()) {
    $message = "Nuevo usuario guardado correctamente";
} else {
    $message = "Error: " . $stmt->error;
}

// Cerrar la conexión
$stmt->close();
$conn->close();

// Mostrar mensaje de alerta y redirigir a Admin.php
echo "<script type='text/javascript'>
        alert('$message');
        window.location.href = 'Admin.php';
      </script>";
?>

