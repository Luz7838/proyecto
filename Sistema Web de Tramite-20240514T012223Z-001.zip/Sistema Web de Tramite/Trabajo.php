<!DOCTYPE html>
<html>
<head>
  <title>Trámites Enviados</title>
  <style>
    body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: block;
            height: 100vh;
        }
        .encabezado{
            display:flex;          
            background-color: red;
            width: 1200px;
            margin:0 auto;
            padding: 5px 0;
        }
        img{
            width: 80px;
            height: 80px;
            padding: 0 10px;
        }
        .encabezado h2{
            color:white;
            padding: 0 10px;
        }
        .navbar {
      overflow: hidden;
      background-color: red;
      display: flex;
      width: 1200px;
      margin:0 auto;
      align-items: stretch; /* Hace que los elementos ocupen toda la altura del contenedor */
    }

    .navbar a {
      display: flex;
      background-color: red;
      align-items: center;
      
      color: white;
      text-align: center;
      text-decoration: none;
      padding: 20px;
      width: 20%;
      margin: 0; /* Elimina cualquier margen que pueda existir */
    }
    .navbar a:hover{
        background-color: #fff;
        color:black;
    }
    .contenedor_general{
        width: 1200px;
        margin:0 auto;
        background-color: #fff;
    }
    .contenedor_tabla{
      

    }
    table{
    border-collapse: collapse;
    box-shadow: 0 5px 10px #B2BABB;
    background-color: white;
    text-align: left;
    overflow: hidden;
    margin:0 auto;
    }
    thead {
      box-shadow: 0 5px 10px #B2BABB;
    }
    th{
      padding: 1rem 2rem;
      text-transform: uppercase;
      letter-spacing: 0.1rem;
      font-size: 0.7rem;
      font-weight: 900;
    }
    td{
      padding: 1rem 2rem;
    }
    td a{
      text-decoration: none;
      color:#5499C7;
    }

  </style>
  <!-- Estilos -->
</head>
<body>
<div class="encabezado">
        <img src="logoMuni.png" alt="">
        <h2>TRAMITES DE LA MUNICIPALIDAD DE SANTA CRUZ DE FLORES</h1>
</div>
<div class="navbar">
  <a href="Trabajo.php">INICIO</a>
  
</div>

  <div class="contenedor_general">
  <div>
    <div class="contenedor_tabla">
    <h2>TRAMITES NUEVOS</h2>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sistemawebtramite";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $sql = "SELECT codigo_tramite, nombre, fecha_envio, correo FROM tabla_tramite WHERE estado = 'enviado'";
    $result = $conn->query($sql);

    echo "<br><table>";
    echo "<thead><tr><th>Código de Trámite</th><th>Nombre</th><th>Fecha de envío</th><th>Correo Electrónico</th></tr></thead>";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tbody>";
            echo "<tr>";
            echo "<td><a href='detalle_tramite.php?codigo=" . $row["codigo_tramite"] . "'>" . $row["codigo_tramite"] . "</a></td>";
            echo "<td>" . $row["nombre"] . "</td>";
            echo "<td>" . $row["fecha_envio"] . "</td>";
            echo "<td>" . $row["correo"] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No se encontraron trámites con estado 'Enviado'.</td></tr>";
    }
    echo "</tbody>";
    echo "</table>";
    ?>
    </div>
    <div>
      <h2>TRAMITES RECHAZADOS</h2>
      <?php
      $sql = "SELECT codigo_tramite, nombre, fecha_envio, correo FROM tabla_tramite WHERE estado = 'rechazado'";
      $result = $conn->query($sql);
  
      echo "<table>";
      echo "<thead><tr><th>Código de Trámite</th><th>Nombre</th><th>Fecha de envío</th><th>Correo Electrónico</th></tr></thead>";
  
      if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo "<tbody>";
              echo "<tr>";
              echo "<td>". $row["codigo_tramite"] . "</a></td>";
              echo "<td>" . $row["nombre"] . "</td>";
              echo "<td>" . $row["fecha_envio"] . "</td>";
              echo "<td>" . $row["correo"] . "</td>";
              echo "</tr>";
          }
      } else {
          echo "<tr><td>No se encontraron trámites con estado 'Enviado'.</td></tr>";
      }
      echo "</tbody>";
      echo "</table>";
      ?>
    </div>
  </div>
  <div>
  <h2>Trámites Recepcionado</h2>
  <?php
      $sql = "SELECT codigo_tramite, nombre, fecha_envio, correo FROM tabla_tramite WHERE estado = 'RECEPCIONADO'";
      $result = $conn->query($sql);
  
      echo "<br><table>";
      echo "<thead><tr><th>Código de Trámite</th><th>Nombre</th><th>Fecha de envío</th><th>Correo Electrónico</th></tr></thead>";
  
      if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo "<tr>";
              echo "<td>". $row["codigo_tramite"] . "</a></td>";
              echo "<td>" . $row["nombre"] . "</td>";
              echo "<td>" . $row["fecha_envio"] . "</td>";
              echo "<td>" . $row["correo"] . "</td>";
              echo "</tr>";
          }
      } else {
          echo "<tr><td colspan='4'>No se encontraron trámites con estado 'RECEPCIONADO'.</td></tr>";
      }
      echo "</table>";
      ?>
  </div>
  <?php
    $conn->close();
    ?>
</body>
</html>

