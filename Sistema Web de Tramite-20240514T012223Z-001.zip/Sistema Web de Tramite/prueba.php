<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generar PDF</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: block;
            height: 100vh;
        }
        .encabezado{
            background-color: red;
            width: 1200px;
            margin:0 auto;
            padding: 5px 0;
        }
        img{
            width: 400px;
            height: 100px;
            padding: 0 10px;
        }
        .encabezado h2{
            color:white;
            padding: 0 10px;
        }
        .form-container {
            width: 1200px;
            margin:0 auto;
            display: flex; 
            gap:5px;
        }

        .generador {
            margin:0 auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 740px;
            box-sizing: border-box;
        }

        h2 {
            color: #333;
        }

        label {
            display: block;
            margin-top: 10px;
            color: #555;
        }

        input, textarea, select {
            width: calc(100% - 16px);
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        button {
            background-color: #4caf50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        #anexos {
            margin-top: 10px;
        }

        #imagenes {
            margin-top: 20px;
        }

        a {
            display: block;
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 10px;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 20px;
        }

        a:hover {
            background-color: #0056b3;
        }
        #aceptar_terminos {
            margin-top: 10px;
            
            
        }
    </style>
</head>
<body>
<div class="encabezado">
        <img src="logo.png" alt="">
        <h2>TRAMITES DE LA MUNICIPALIDAD DE SANTA CRUZ DE FLORES</h1>
</div>
<div class="form-container">
    <div class="generador">
        <h2>Generar un FUT(Formulario Unico de Tramite)</h2>
        <label for="nombre">Nombres y Apellidos:</label>
        <input type="text" placeholder="Escribeme tu nombres y apellidos" id="nombre">
        <label for="">DNI:</label>
        <input type="text" id="dni">
        <label for="">Domicilio:</label>
        <input type="text" id="domicilio">
        <label for="">Correo Electronico:</label>
        <input type="text" id="correo">
        <label for="">Numero de Celular:</label>
        <input type="text" id="celular">
        <label for="">Originario de :</label>
        <input type="text" id="originario">
        <label for="">Solicito:</label>
        <input type="text" id="asunto">
        <label for="">Motivos de su Solicitud:</label>
        <textarea name="motivos" id="motivos" cols="30" rows="10"></textarea>
        <div id="anexos">
            <label for="anexo1">Nombre del Anexo 1:</label>
            <input type="text" id="anexo1">
        </div>
        <button onclick="agregarCampo()">Agregar Anexo</button>

        <a href="javascript:genPDF()">Crear pdf</a>
    </div>
    <div class="generador">
            <form action="guardar.php" method="post" enctype="multipart/form-data">
            <h2>Enviar Fut</h2>
            <label for="nombre">Nombre y Apellidos:</label>
            <input type="text" id="nombre" name="nombre" required><br>

            <label for="archivo">Archivo PDF:</label>
            <input type="file" id="archivo" name="archivo" accept=".pdf" required><br>

            <input type="submit" value="Enviar">
            </form>
            
        </div>
</div>
    <script type="text/javascript" src="jspdf.min.js"></script>
    <script type="text/javascript">
        let contadorAnexos = 1;

        function agregarCampo() {
            contadorAnexos++;
            const divAnexos = document.getElementById('anexos');
            const nuevoCampo = document.createElement('div');
            nuevoCampo.innerHTML = `<label for="anexo${contadorAnexos}">Nombre del Anexo ${contadorAnexos}:</label><br>
                                    <input type="text" id="anexo${contadorAnexos}"><br>`;
            divAnexos.appendChild(nuevoCampo);
        }


        function genPDF(){
            var doc=new jsPDF();
            doc.setFontSize(12);
            doc.setFont("times");
            let nombre=document.getElementById('nombre').value;
            let dni=document.getElementById('dni').value;
            let domicilio=document.getElementById('domicilio').value;
            let asunto=document.getElementById('asunto').value;
            let originario=document.getElementById('originario').value;
            let motivos=document.getElementById('motivos').value;
            let correo=document.getElementById('correo').value;
            let celular=document.getElementById('celular').value;
            let today = new Date();
            
            // Añadir la lógica para cargar y mostrar la imagen
            let inputImagen = document.getElementById('imagen');
            let imagen = inputImagen.files[0];

            // Nombres de los meses en español
            let meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];

            let fecha = today.getDate() + ' de ' + meses[today.getMonth()] + ' del ' + today.getFullYear();
            doc.text(70,20,'FORMULARIO UNICO DE TRAMITE');
            doc.text(100,30,"Solicito: "+asunto);
            doc.text(20, 40, `Señor alcalde de la municipalidad de Santa Cruz de flores:`);
            let textoParrafo = `Yo ${nombre}, identificado(a) con D.N.I. N° ${dni}, domiciliado(a) en ${domicilio}, natural de ${originario}, ante su despacho me presento y digo:`;
            let splitText1 = doc.splitTextToSize(textoParrafo, 170);
            doc.text(20, 50, splitText1);
            

            doc.text(20,80,"MOTIVOS DE LA SOLICITUD:");
            let splitText = doc.splitTextToSize(motivos, 170);
            doc.text(20, 90, splitText);
            doc.text(20,140,"POR LO EXPUESTO:");
            doc.text(20,150,"Es justicia lo que espero alcansar.");
            doc.text(20,160,"ANEXOS:");
            let y = 170; // Posición inicial para los anexos
            for (let i = 1; i <= contadorAnexos; i++) {
                let nombreAnexo = document.getElementById(`anexo${i}`).value;
                doc.text(20, y, `${i}) ${nombreAnexo}`);
                y += 10;
            }
            doc.text(90,220,"Santa Cruz de Flores "+fecha);
            doc.text(20, 230, "Nombres y Apellidos: "+nombre);
            doc.text(20, 240, "Tlf./Cel: "+celular);
            doc.text(90, 240, "Gmail: "+correo);
            doc.addPage();

        }
    </script>
</body>
</html>