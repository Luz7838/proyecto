  <!DOCTYPE html>
  <html>
  <head>
    <title>Consulta de trámite</title>
    <style>
      body {
              font-family: 'Arial', sans-serif;
              background-color: #f4f4f4;
              margin: 0;
              padding: 0;
              display: block;
              height: 100vh;
          }
          .encabezado{
              display:flex;
              background-color: red;
              width: 1220px;
              margin:0 auto;
              padding: 5px 0;
          }
          img{
              width: 80px;
              height: 80px;
              padding: 0 10px;
          }
          .encabezado h2{
              color:white;
              padding: 0 10px;
          }
          .navbar {
        overflow: hidden;
        background-color: red;
        display: flex;
        width: 1220px;
        margin:0 auto;
        align-items: stretch; /* Hace que los elementos ocupen toda la altura del contenedor */
      }

      .navbar a {
        display: flex;
        background-color: red;
        align-items: center;
        border-radius:5px;
        color: white;
        text-align: center;
        text-decoration: none;
        padding: 20px;
        width: 20%;
        margin: 0; /* Elimina cualquier margen que pueda existir */
      }
      .navbar a:hover{
          background-color: #fff;
          color:black;
      }
      .contenedor_general{
          width: 1180px;
          margin: 0 auto;
          background-color: #fff;
          padding: 20px;
          
      }

      table{
    border-collapse: collapse;
    box-shadow: 0 5px 10px #B2BABB;
    background-color: white;
    text-align: left;
    overflow: hidden;
    margin:0 auto;
    }
    thead {
      box-shadow: 0 5px 10px #B2BABB;
    }
    th{
      padding: 1rem 2rem;
      text-transform: uppercase;
      letter-spacing: 0.1rem;
      font-size: 0.7rem;
      font-weight: 900;
    }
    td{
      padding: 1rem 2rem;
    }
    td a{
      text-decoration: none;
      color:#5499C7;
    }
    .estado_verde{
      border-radius: 2px;
      background-color: #27AE60;
      padding: 0.2rem 1rem;
      text-align: center;
      color:#fff;
    }
    .estado_naranja{
      border-radius: 2px;
      background-color: #F39C12;
      padding: 0.2rem 1rem;
      text-align: center;
      color:#fff;
    }
    .estado_rojo{
      border-radius: 2px;
      background-color: red;
      padding: 0.2rem 1rem;
      text-align: center;
      color:#fff;
    }

      

      
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  </head>
  <body>
  <div class="encabezado">
          <img src="logoMuni.png" alt="">
          <h2>TRAMITES DE LA MUNICIPALIDAD DE SANTA CRUZ DE FLORES</h1>
  </div>
  <div class="navbar">
    <a href="index.php">INICIO</a>
    <a href="consulta.php">CONSULTA DE ESTADO</a>
    
  </div>
  <div class="contenedor_general">
    <h2>Consulta de trámite</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <label for="codigo_o_correo">Código de trámite o Correo Electrónico:</label>
      <input type="text" id="codigo_o_correo" name="codigo_o_correo">
      <input type="submit" value="Consultar">
    </form>



    <br>

    <?php
            // Conexión a la base de datos y lógica de consulta existente
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "sistemawebtramite";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Conexión fallida: " . $conn->connect_error);
            }

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $codigo_o_correo = $_POST['codigo_o_correo'];

                $sql = "SELECT codigo_tramite, nombre, fecha_envio, fecha_atencion, estado, correo, Mensaje, id FROM tabla_tramite WHERE codigo_tramite = '$codigo_o_correo' OR correo = '$codigo_o_correo'";
                $result = $conn->query($sql);

                echo "<br><table>";
                echo "<thead><tr><th>Nombre</th><th>Fecha de envío</th><th>Fecha de atención</th><th>Correo Electrónico</th><th>Estado</th><th>Mensaje</th><th>Acciones</th></tr></thead>";

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $fecha_actual = strtotime(date("Y-m-d"));
                        $fecha_atencion = strtotime($row["fecha_atencion"]);
                        $diferencia_dias = ($fecha_actual - $fecha_atencion) / (60 * 60 * 24);

                        echo "<tr>";
                        echo "<tbody>";
                        echo "<td>" . $row["nombre"] . "</td>";
                        echo "<td>" . $row["fecha_envio"] . "</td>";
                        echo "<td>" . $row["fecha_atencion"] . "</td>";
                        echo "<td>" . $row["correo"] . "</td>";

                        // Agregar lógica para cambiar el color según los rangos de tiempo y el estado
                        if ($row["estado"] == "SUBSANAR") {
                            if ($diferencia_dias < 3) {
                                echo "<td><p class='estado_verde'>" . $row["estado"] . "</p></td>";
                            } elseif ($diferencia_dias >= 3 && $diferencia_dias < 6) {
                              echo "<td><p class='estado_naranja'>" . $row["estado"] . "</p></td>";
                            } else {
                              echo "<td><p class='estado_rojo'>" . $row["estado"] . "</p></td>";
                            }
                        } else {
                          echo "<td><p class='estado_verde'>" . $row["estado"] . "</p></td>";
                        }

                        echo "<td style='width: 300px;'>" . $row["Mensaje"] . "</td>";

                        // Agregar lógica para el reenvío del PDF si el estado es "SUBSANAR"
                        if ($row["estado"] == "SUBSANAR") {
                            echo "<td><a href='reenviar_pdf.php?codigo=" . $row["codigo_tramite"] . "'><i class='fas fa-download'></i>SubirPdf</a></td>";
                        } else {
                            echo "<td></td>";
                        }

                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No se encontraron resultados para el código de trámite o correo electrónico proporcionado.</td></tr>";
                }
                echo "<tbody>";
                echo "</table>";
                $conn->close();
            }
        ?>

  </div>
  </body>
  </html>

