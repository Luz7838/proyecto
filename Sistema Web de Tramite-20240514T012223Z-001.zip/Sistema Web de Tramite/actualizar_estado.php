<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistemawebtramite";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_tramite = $_POST['codigo_tramite'];

    if (isset($_POST['recepcionado'])) {
        // Si se presionó el botón "Marcar como Recepcionado"
        $estado = "RECEPCIONADO";
    } elseif (isset($_POST['rechazado'])) {
        // Si se presionó el botón "Marcar como Rechazado"
        $estado = "RECHAZADO";
    } elseif (isset($_POST['subsanar'])) {
        // Si se presionó el botón "Subsanar"
        $estado = "SUBSANAR";
    }

    // Obtener el mensaje del formulario
    $mensaje = $_POST['mensaje']; // Nombre del campo de texto en el formulario

    // Obtener la fecha actual
    $fecha_atencion = date("Y-m-d H:i:s");

    // Actualizar el estado, el mensaje y la fecha de atención del trámite en la base de datos
    $update_sql = "UPDATE tabla_tramite SET estado = '$estado', mensaje = '$mensaje', fecha_atencion = '$fecha_atencion' WHERE codigo_tramite = '$codigo_tramite'";
    if ($conn->query($update_sql) === TRUE) {
        // Mensaje de alerta en caso de éxito
        echo '<script>alert("El estado, el mensaje y la fecha de atención han sido actualizados correctamente."); window.location.href = "Trabajo.php";</script>';
        exit;
    } else {
        // Mensaje de alerta en caso de error
        echo '<script>alert("Error al actualizar el estado, el mensaje y la fecha de atención: ' . $conn->error . '"); window.location.href = "Trabajo.php";</script>';
    }
}

$conn->close();

?>


