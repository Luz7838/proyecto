<?php
// Verifica si se ha enviado un formulario con un archivo y un código de trámite
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['codigo_tramite']) && isset($_FILES['pdf_file'])) {
    $codigo_tramite = $_POST['codigo_tramite'];

    // Verifica si no hubo errores en la subida del archivo
    if ($_FILES['pdf_file']['error'] === UPLOAD_ERR_OK) {
        $archivo = $_FILES['pdf_file']['tmp_name'];
        $nombre_archivo = $_FILES['pdf_file']['name'];

        $carpeta_destino = __DIR__ . "/PDF/";
        $ruta_archivo_destino = $carpeta_destino . $nombre_archivo;

        // Intenta mover el archivo a la carpeta destino
        if (move_uploaded_file($archivo, $ruta_archivo_destino)) {
            // Realiza la actualización en la base de datos con la ruta del archivo PDF y el estado "ENVIADO"
            $servername = "localhost";
            $username = "root";
            $password = "12345678";
            $dbname = "sistemawebtramite";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Conexión fallida: " . $conn->connect_error);
            }

            // Actualiza la tabla con la ruta del archivo PDF y el estado "ENVIADO" para el código de trámite proporcionado
            $sql = "UPDATE tu_tabla SET archivo = '$ruta_archivo_destino', estado = 'ENVIADO' WHERE codigo_tramite = '$codigo_tramite'";
            if ($conn->query($sql) === TRUE) {
                $message = "El archivo se ha subido correctamente y la base de datos se ha actualizado.";
                echo '<script>alert("' . $message . '"); window.location.href = "consulta.php";</script>';
            } else {
                echo '<script>alert("Error al actualizar la base de datos: ' . $conn->error . '");</script>';
            }

            $conn->close();
        } else {
            echo '<script>alert("Hubo un error al subir el archivo.");</script>';
        }
    } else {
        echo '<script>alert("No se ha seleccionado un archivo o ha ocurrido un error al cargarlo.");</script>';
    }
} else {
    echo '<script>alert("No se ha enviado el formulario correctamente.");</script>';
}
?>
