<?php
if (isset($_GET['nombre_archivo'])) {
    $archivo_descarga = $_GET['nombre_archivo'];
    $archivo_descarga = basename($archivo_descarga); // Para asegurar que el nombre sea seguro

    $ruta_completa = 'C:/AppServ/www/Sistema Web de Tramite/PDF/' . $archivo_descarga;

    if (file_exists($ruta_completa)) {
        // Encabezados para la descarga
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($ruta_completa) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($ruta_completa));
        readfile($ruta_completa); // Descargar el archivo
        exit;
    } else {
        echo "El archivo no existe.";
    }
} else {
    echo "No se proporcionó un nombre de archivo para descargar.";
}
?>
