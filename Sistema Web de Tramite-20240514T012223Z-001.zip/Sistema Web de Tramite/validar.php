<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "connection.php";

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Consulta para verificar las credenciales en la base de datos
    $sql = "SELECT * FROM usuarios WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // Inicio de sesión exitoso
        $_SESSION['username'] = $username;
        header('Location: Trabajo.php');
        exit;
    } else {
        echo "Credenciales incorrectas. Inténtalo de nuevo.";
    }
    $conn->close();
}
?>
