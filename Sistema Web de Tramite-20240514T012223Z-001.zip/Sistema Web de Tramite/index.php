<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generar PDF</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: block;
            height: 100vh;
        }
        .encabezado{
            display:flex;
            background-color: red;
            width: 1200px;
            margin:0 auto;
            padding: 5px 0;
        }
        img{
            width: 80px;
            height: 80px;
            padding: 0 10px;
        }
        .encabezado h2{
            color:white;
            padding: 0 10px;
        }
        .navbar {
      overflow: hidden;
      background-color: red;
      text-align: center;
      display: flex;
      width: 1200px;
      margin:0 auto; 
            
    }

    .navbar a {
      display: flex;
      background-color: red;
      font-weight: bold;      
      color: white;
      text-decoration: none;
      padding: 20px;
      
      width: 20%;
      margin: 0; 
    }
    .navbar a:hover{
        background-color: #fff;
        color:black;
        font-weight: bold;
        
    }
        
        .form-container {
            width: 1200px;
            margin:0 auto;
            display: flex; 
            gap:5px;
        }

        .generador {
            margin:0 auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 740px;
            box-sizing: border-box;
        }

        h2 {
            color: #333;
        }

        label {
            display: block;
            margin-top: 10px;
            color: #555;
        }

        input, textarea, select {
            width: calc(100% - 16px);
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        button {
            background-color: #4caf50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        #anexos {
            margin-top: 10px;
        }

        #imagenes {
            margin-top: 20px;
        }

        .generar_pdf {
            display: block;
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 10px;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 20px;
        }

        .generar_pdf:hover {
            background-color: #0056b3;
        }
        #aceptar_terminos {
            margin-top: 10px;
            
            
        }
    </style>
</head>
<body>
<div class="encabezado">
        <img src="logoMuni.png" alt="">
        <h2>TRAMITES DE LA MUNICIPALIDAD DE SANTA CRUZ DE FLORES</h1>
</div>
<div class="navbar">
  <a href="index.php">INICIO</a>
  <a href="consulta.php">CONSULTA DE TRAMITES</a>
  
</div>
<div class="form-container">
    <div class="generador">
        <h2>Generar un FUT(Formulario Unico de Tramite)</h2>
        <label for="nombre">Nombres y Apellidos:</label>
        <input type="text" placeholder="Escribeme tu nombres y apellidos" id="nombre">
        <label for="">DNI:</label>
        <input type="text" id="dni">
        <label for="">Domicilio:</label>
        <input type="text" id="domicilio">
        <label for="">Correo Electronico:</label>
        <input type="text" id="correo">
        <label for="">Numero de Celular:</label>
        <input type="text" id="celular">
        <label for="">Originario de :</label>
        <input type="text" id="originario">
        <label for="">Solicito:</label>
        <input type="text" id="asunto">
        <label for="">Motivos de su Solicitud:</label>
        <textarea name="motivos" id="motivos" cols="30" rows="10"></textarea>
        <div id="anexos">
            <label for="anexo1">Nombre del Anexo 1:</label>
            <input type="text" id="anexo1">
        </div>
        <button onclick="agregarCampo()">Agregar Anexo</button>
        <label for="imagen">Cargar Imagenes de los Anexos:</label>
        <div id="imagenes">
            <input type="file" id="imagen" name="imagen" accept="image/*">
        </div>
        <button onclick="agregarImagen()">Agregar Imagen</button>
        <a class="generar_pdf" href="javascript:genPDF()">Crear FUT</a>
    </div>
    <div class="generador">
            <form action="guardar.php" method="post" enctype="multipart/form-data">
            <h2>Enviar Fut</h2>
            <label for="nombre">Nombre y Apellidos:</label>
            <input type="text" id="nombre2" name="nombre" required><br>
            <label for="">Telefono o Celular:</label>
            <input type="text" id="celular2" name="celular">
            <label for="">Correo Electronico:</label>
            <input type="text" id="correo2" name="correo">
            <label for="">Domicilio:</label>
            <input type="text" id="domicilio2">
            <label for="">Asunto:</label>
            <input type="text" id="asunto2">
            <label for="archivo">Archivo PDF:</label>
            <input type="file" id="archivo" name="archivo" accept=".pdf" required><br>
            <button onclick="refreshPage()">CANCELAR TRAMITE</button>

            <input type="submit" value="Enviar">
            </form>
            
        </div>
</div>
    <script type="text/javascript" src="jspdf.min.js"></script>
    <script type="text/javascript">
        let contadorAnexos = 1;
        let contadorImagenes = 1;

        function agregarCampo() {
            contadorAnexos++;
            const divAnexos = document.getElementById('anexos');
            const nuevoCampo = document.createElement('div');
            nuevoCampo.innerHTML = `<label for="anexo${contadorAnexos}">Nombre del Anexo ${contadorAnexos}:</label><br>
                                    <input type="text" id="anexo${contadorAnexos}"><br>`;
            divAnexos.appendChild(nuevoCampo);
        }
        function agregarImagen() {
        contadorImagenes++;
        const divImagenes = document.getElementById('imagenes');
        const nuevaImagen = document.createElement('input');
        nuevaImagen.setAttribute('type', 'file');
        nuevaImagen.setAttribute('id', `imagen${contadorImagenes}`);
        nuevaImagen.setAttribute('name', 'imagen');
        nuevaImagen.setAttribute('accept', 'image/*');
        divImagenes.appendChild(nuevaImagen);
    }
        function genPDF() {
    var doc = new jsPDF();
    doc.setFontSize(12);
    doc.setFont("times");

    let logo = new Image();
    logo.src = 'logo.png'; // Reemplazar con la ruta de tu logo
    logo.onload = function() {
        doc.addImage(logo, 'PNG', 15, 10, 40, 20);

    let nombre = document.getElementById('nombre').value;
    let dni = document.getElementById('dni').value;
    let domicilio = document.getElementById('domicilio').value;
    let asunto = document.getElementById('asunto').value;
    let originario = document.getElementById('originario').value;
    let motivos = document.getElementById('motivos').value;
    let correo = document.getElementById('correo').value;
    let celular = document.getElementById('celular').value;
    let today = new Date();
    let nombreValor = document.getElementById('nombre').value;
            let celularValor = document.getElementById('celular').value;
            let correoValor = document.getElementById('correo').value;
            let domicilioValor = document.getElementById('domicilio').value;
            let asuntoValor = document.getElementById('asunto').value;
            document.getElementById('nombre2').value = nombreValor;
            document.getElementById('celular2').value = celularValor;
            document.getElementById('correo2').value = correoValor;
            document.getElementById('domicilio2').value = domicilioValor;
            document.getElementById('asunto2').value = asuntoValor;
            // Deshabilitar los campos del primer formulario
            document.getElementById('nombre').disabled = true;
            document.getElementById('dni').disabled = true;
            document.getElementById('domicilio').disabled = true;
            document.getElementById('asunto').disabled = true;
            document.getElementById('originario').disabled = true;
            document.getElementById('motivos').disabled = true;
            document.getElementById('correo').disabled = true;
            document.getElementById('celular').disabled = true;
            document.getElementById('asunto').disabled = true;
            document.getElementById('domicilio').disabled = true;

    // Nombres de los meses en español
    let meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];

    let fecha = today.getDate() + ' de ' + meses[today.getMonth()] + ' del ' + today.getFullYear();
    doc.text(70, 20, 'FORMULARIO UNICO DE TRAMITE');
    doc.text(100, 30, "Solicito: " + asunto);
    doc.text(20, 40, `Señor alcalde de la municipalidad de Santa Cruz de flores:`);
    let textoParrafo = `Yo ${nombre}, identificado(a) con D.N.I. N° ${dni}, domiciliado(a) en ${domicilio}, natural de ${originario}, ante su despacho me presento y digo:`;
    let splitText1 = doc.splitTextToSize(textoParrafo, 170);
    doc.text(20, 50, splitText1);

    doc.text(20, 80, "MOTIVOS DE LA SOLICITUD:");
    let splitText = doc.splitTextToSize(motivos, 170);
    doc.text(20, 90, splitText);
    doc.text(20, 140, "POR LO EXPUESTO:");
    doc.text(20, 150, "Es justicia lo que espero alcanzar.");
    doc.text(20, 160, "ANEXOS:");
    let y = 170; // Posición inicial para los anexos
    for (let i = 1; i <= contadorAnexos; i++) {
        let nombreAnexo = document.getElementById(`anexo${i}`).value;
        doc.text(20, y, `${i}) ${nombreAnexo}`);
        y += 10;
    }
    doc.text(90, 220, "Santa Cruz de Flores, " + fecha);
    doc.text(20, 230, "Nombres y Apellidos: " + nombre);
    doc.text(20, 240, "Tlf./Cel: " + celular);
    doc.text(90, 240, "Gmail: " + correo);


    let imgInputs = document.querySelectorAll('input[type=file][id^=imagen]');
        let imgCounter = 0;

        function addNextImage() {
            if (imgCounter < imgInputs.length) {
                let imgInput = imgInputs[imgCounter];
                if (imgInput.files && imgInput.files[0]) {
                    let reader = new FileReader();
                    reader.onload = function (e) {
                        let imgData = e.target.result;
                        doc.addPage(); // Agregar una nueva página para la imagen
                        doc.addImage(imgData, 'JPEG', 15, 15, 180, 120);
                        imgCounter++;
                        addNextImage(); // Procesar la siguiente imagen
                    };
                    reader.readAsDataURL(imgInput.files[0]);
                } else {
                    imgCounter++;
                    addNextImage(); // Procesar la siguiente imagen
                }
            } else {
                doc.save('FUT.pdf'); // Guardar el PDF una vez se hayan añadido todas las imágenes
            }
        }

        addNextImage(); 
    }
}
  function refreshPage() {
    // Esta línea recarga la página actual
    location.reload();
  }


    </script>
</body>
</html>