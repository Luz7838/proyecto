<?php
// Aquí se establece la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = " ";
$dbname = "sistemawebtramite";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener el código de trámite enviado desde el formulario
    $codigo_tramite = $_POST['codigo_tramite'];

    // Consulta SQL para obtener la información del trámite
    $sql = "SELECT nombre, fecha_envio, estado FROM tu_tabla WHERE codigo_tramite = '$codigo_tramite'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Mostrar los resultados obtenidos
        while ($row = $result->fetch_assoc()) {
            echo "Nombre: " . $row["nombre"] . "<br>";
            echo "Fecha: " . $row["fecha"] . "<br>";
            echo "Estado: " . $row["estado"] . "<br>";
        }
    } else {
        echo "No se encontraron resultados para el código de trámite proporcionado.";
    }
    $conn->close();
}
?>
