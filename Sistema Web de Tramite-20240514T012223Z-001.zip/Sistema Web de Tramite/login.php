<!DOCTYPE html>
<html>
<head>
  <title>Iniciar sesión</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }
    .container {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
    .login-container {
      width: 800px;
      background: #fff;
      padding: 40px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      display: flex;
      align-items: center;
    }
    .login-form {
      flex-grow: 1;
      margin-left: 20px;
      padding:5px;
    }
    h2 {
      color: #333;
      text-align: center;
    }
    label {
      display: block;
      margin-bottom: 5px;
      color: #333;
    }
    input[type="text"],
    input[type="password"] {
      width: calc(100% - 12px);
      padding: 6px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
    }
    input[type="submit"] {
      width: 100%;
      padding: 8px;
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 3px;
      cursor: pointer;
    }
    input[type="submit"]:hover {
      background-color: #0056b3;
    }
    a {
      display: block;
      text-align: right;
      margin:10px 30px;

      text-decoration: none;
      color: #007bff;
    }
    a:hover {
      text-decoration: underline;
    }
    .login-image {
      display:flex;
      aling-items:center;
      justify-content: center;  
      width: 50%;
      height: 400px;
    }
    .login-image img {
      width: 300px;
      height: 90%;
      object-fit: cover;
      border-radius: 5px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="login-container">
      <div class="login-image">
        <img src="logoMuni.png" alt="Imagen de inicio de sesión">
      </div>
      <div class="login-form">
        <h2>Iniciar sesión</h2>
        <form action="validar.php" method="post">
          <label for="username">Usuario:</label>
          <input type="text" id="username" name="username" autocomplete="off">
          <label for="password">Contraseña:</label>
          <input type="password" id="password" name="password" autocomplete="off">
          <a href="recuperar.php">¿Olvidaste tu contraseña?</a>
          <input type="submit" value="Iniciar sesión">
        </form>
      </div>
    </div>
  </div>
</body>
</html>
