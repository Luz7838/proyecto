<!DOCTYPE html>
<html>
<head>
    <title>Detalle del Trámite</title>
    <style>
    body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: block;
            height: 100vh;
        }
        .encabezado{
            background-color: red;
            width: 1200px;
            margin:0 auto;
            padding: 5px 0;
        }
        img{
            width: 400px;
            height: 100px;
            padding: 0 10px;
        }
        .encabezado h2{
            color:white;
            padding: 0 10px;
        }
        .navbar {
      overflow: hidden;
      background-color: red;
      display: flex;
      width: 1200px;
      margin:0 auto;
      align-items: stretch; /* Hace que los elementos ocupen toda la altura del contenedor */
    }

    .navbar a {
      display: flex;
      background-color: red;
      align-items: center;
      border-radius:5px;
      color: white;
      text-align: center;
      text-decoration: none;
      padding: 20px;
      width: 20%;
      margin: 0; /* Elimina cualquier margen que pueda existir */
    }
    .navbar a:hover{
        background-color: #fff;
        color:black;
    }
    .contenedor_general{
        width: 1200px;
        margin:0 auto;
        background-color: #fff;
        padding: 10px 0;
    }
    .contenedor2{
        width: 80%;
            margin: auto;
            background-color: #f9f9f9;
            padding: 20px;
            border:1px solid black;
            border-radius: 8px;
            
    }
    .contenedor_general h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .contenedor_general p {
            margin-bottom: 10px;
        }

        .contenedor_general a {
            text-decoration: none;
            color: blue;
        }

        .contenedor_general a:hover {
            text-decoration: underline;
        }

        .contenedor_general form input[type='submit'] {
            padding: 8px 16px;
            margin-right: 10px;
            border-radius: 4px;
            border: none;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }

        input[type='file'] {
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        width: 100%;
    }

    /* Estilos para el botón de enviar */
    button[type='submit'] {
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        background-color: #007bff;
        color: white;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    button[type='submit']:hover {
        background-color: #0056b3;
    }
    .generador {
            margin:0 auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 740px;
            box-sizing: border-box;
        }

        h2 {
            color: #333;
        }

        label {
            display: block;
            margin-top: 10px;
            color: #555;
        }

        input, textarea, select {
            width: calc(100% - 16px);
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        .generar_pdf {
            display: block;
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 10px;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 20px;
        }

        .generar_pdf:hover {
            background-color: #0056b3;
        }
        #aceptar_terminos {
            margin-top: 10px;
            
            
        }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <!-- Encabezado y navegación -->
    <div class="encabezado">
        <img src="logo.png" alt="">
        <h2>TRAMITES DE LA MUNICIPALIDAD DE SANTA CRUZ DE FLORES</h1>
</div>
<div class="navbar">
  <a href="Trabajo.php">INICIO</a>
  
</div>
    <div class="contenedor_general">
        <div class="contenedor2">
        <h2>Detalle del Trámite</h2>

        <?php
            // Conexión a la base de datos y código PHP existente
            $servername = "localhost";
            $username = "root";
            $password = "12345678";
            $dbname = "sistemawebtramite";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Conexión fallida: " . $conn->connect_error);
            }

            // Verificar si se ha proporcionado un código de trámite en la URL
            if (isset($_GET['codigo'])) {
                $codigo_tramite = $_GET['codigo'];

                // Realizar la consulta para obtener los detalles del trámite con el código proporcionado
                $sql = "SELECT * FROM tu_tabla WHERE codigo_tramite = '$codigo_tramite'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    // Mostrar los detalles del trámite
                    echo "<p><strong>Código de Trámite:</strong> " . $row["codigo_tramite"] . "</p>";
                    echo "<p><strong>Nombre:</strong> " . $row["nombre"] . "</p>";
                    echo "<p><strong>Fecha de envío:</strong> " . $row["fecha_envio"] . "</p>";
                    echo "<p><strong>Correo Electrónico:</strong> " . $row["correo"] . "</p>";
                    
                    // Enlace al archivo guardado
                    $archivo = $row["archivo"];
                    echo "<p><strong>Archivo:</strong> <a href='descarga.php?nombre_archivo=" . urlencode($archivo) . "'><i class='fas fa-download'></i> Descargar archivo</a></p>";
                    
                    // Formulario para actualizar el estado y cargar el archivo PDF
                    echo "<form action='procesar_envio.php' method='post' enctype='multipart/form-data'>";
                    
                    // Nuevo campo de carga de archivo para el PDF
                    echo "<label for='pdf_file'><strong>Subir PDF:</strong></label>";
                    echo "<input type='file' id='pdf_file' name='pdf_file' accept='.pdf' style='margin-bottom: 10px;'>";

                    // Campo oculto para el código de trámite
                    echo "<input type='hidden' name='codigo_tramite' value='" . $row["codigo_tramite"] . "'>";

                    // Botón para enviar el formulario
                    echo "<button type='submit'>Enviar</button>";
                    
                    echo "</form>";

                    // ... otros campos que desees mostrar ...
                } else {
                    echo "No se encontró el trámite especificado.";
                }
            } else {
                echo "No se proporcionó un código de trámite.";
            }

            $conn->close();
            ?>
        </div>
        <div class="generador">
        <h2>Generar un nuevo FUT(Formulario Unico de Tramite)</h2>
        <label for="nombre">Nombres y Apellidos:</label>
        <input type="text" placeholder="Escribeme tu nombres y apellidos" id="nombre">
        <label for="">DNI:</label>
        <input type="text" id="dni">
        <label for="">Domicilio:</label>
        <input type="text" id="domicilio">
        <label for="">Correo Electronico:</label>
        <input type="text" id="correo">
        <label for="">Numero de Celular:</label>
        <input type="text" id="celular">
        <label for="">Originario de :</label>
        <input type="text" id="originario">
        <label for="">Solicito:</label>
        <input type="text" id="asunto">
        <label for="">Motivos de su Solicitud:</label>
        <textarea name="motivos" id="motivos" cols="30" rows="10"></textarea>
        <div id="anexos">
            <label for="anexo1">Nombre del Anexo 1:</label>
            <input type="text" id="anexo1">
        </div>
        <button onclick="agregarCampo()">Agregar Anexo</button>
        <label for="imagen">Cargar Imagenes de los Anexos:</label>
        <div id="imagenes">
            <input type="file" id="imagen" name="imagen" accept="image/*">
        </div>
        <button onclick="agregarImagen()">Agregar Imagen</button>
        <a class="generar_pdf" href="javascript:genPDF()">Crear FUT</a>
    </div>
    </div>
    <script type="text/javascript" src="jspdf.min.js"></script>
    <script type="text/javascript">
        let contadorAnexos = 1;
        let contadorImagenes = 1;

        function agregarCampo() {
            contadorAnexos++;
            const divAnexos = document.getElementById('anexos');
            const nuevoCampo = document.createElement('div');
            nuevoCampo.innerHTML = `<label for="anexo${contadorAnexos}">Nombre del Anexo ${contadorAnexos}:</label><br>
                                    <input type="text" id="anexo${contadorAnexos}"><br>`;
            divAnexos.appendChild(nuevoCampo);
        }
        function agregarImagen() {
        contadorImagenes++;
        const divImagenes = document.getElementById('imagenes');
        const nuevaImagen = document.createElement('input');
        nuevaImagen.setAttribute('type', 'file');
        nuevaImagen.setAttribute('id', `imagen${contadorImagenes}`);
        nuevaImagen.setAttribute('name', 'imagen');
        nuevaImagen.setAttribute('accept', 'image/*');
        divImagenes.appendChild(nuevaImagen);
    }
        function genPDF() {
    var doc = new jsPDF();
    doc.setFontSize(12);
    doc.setFont("times");

    let logo = new Image();
    logo.src = 'logo.png'; // Reemplazar con la ruta de tu logo
    logo.onload = function() {
        doc.addImage(logo, 'PNG', 15, 10, 40, 20);

    let nombre = document.getElementById('nombre').value;
    let dni = document.getElementById('dni').value;
    let domicilio = document.getElementById('domicilio').value;
    let asunto = document.getElementById('asunto').value;
    let originario = document.getElementById('originario').value;
    let motivos = document.getElementById('motivos').value;
    let correo = document.getElementById('correo').value;
    let celular = document.getElementById('celular').value;
    let today = new Date();
    

    // Nombres de los meses en español
    let meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];

    let fecha = today.getDate() + ' de ' + meses[today.getMonth()] + ' del ' + today.getFullYear();
    doc.text(70, 20, 'FORMULARIO UNICO DE TRAMITE');
    doc.text(100, 30, "Solicito: " + asunto);
    doc.text(20, 40, `Señor alcalde de la municipalidad de Santa Cruz de flores:`);
    let textoParrafo = `Yo ${nombre}, identificado(a) con D.N.I. N° ${dni}, domiciliado(a) en ${domicilio}, natural de ${originario}, ante su despacho me presento y digo:`;
    let splitText1 = doc.splitTextToSize(textoParrafo, 170);
    doc.text(20, 50, splitText1);

    doc.text(20, 80, "MOTIVOS DE LA SOLICITUD:");
    let splitText = doc.splitTextToSize(motivos, 170);
    doc.text(20, 90, splitText);
    doc.text(20, 140, "POR LO EXPUESTO:");
    doc.text(20, 150, "Es justicia lo que espero alcanzar.");
    doc.text(20, 160, "ANEXOS:");
    let y = 170; // Posición inicial para los anexos
    for (let i = 1; i <= contadorAnexos; i++) {
        let nombreAnexo = document.getElementById(`anexo${i}`).value;
        doc.text(20, y, `${i}) ${nombreAnexo}`);
        y += 10;
    }
    doc.text(90, 220, "Santa Cruz de Flores, " + fecha);
    doc.text(20, 230, "Nombres y Apellidos: " + nombre);
    doc.text(20, 240, "Tlf./Cel: " + celular);
    doc.text(90, 240, "Gmail: " + correo);


    let imgInputs = document.querySelectorAll('input[type=file][id^=imagen]');
        let imgCounter = 0;

        function addNextImage() {
            if (imgCounter < imgInputs.length) {
                let imgInput = imgInputs[imgCounter];
                if (imgInput.files && imgInput.files[0]) {
                    let reader = new FileReader();
                    reader.onload = function (e) {
                        let imgData = e.target.result;
                        doc.addPage(); // Agregar una nueva página para la imagen
                        doc.addImage(imgData, 'JPEG', 15, 15, 180, 120);
                        imgCounter++;
                        addNextImage(); // Procesar la siguiente imagen
                    };
                    reader.readAsDataURL(imgInput.files[0]);
                } else {
                    imgCounter++;
                    addNextImage(); // Procesar la siguiente imagen
                }
            } else {
                doc.save('FUT.pdf'); // Guardar el PDF una vez se hayan añadido todas las imágenes
            }
        }

        addNextImage(); 
    }
}



    </script>
</body>
</html>


