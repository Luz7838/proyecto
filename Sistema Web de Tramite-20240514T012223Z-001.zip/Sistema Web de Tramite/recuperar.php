<!DOCTYPE html>
<html>
<head>
  <title>Cambio de contraseña</title>
</head>
<body>
  <h2>Cambio de contraseña</h2>
  <form action="cambiar_contraseña.php" method="post">
    <label for="username">Usuario:</label><br>
    <input type="text" id="username" name="username"><br>
    <label for="security_pin">PIN de seguridad:</label><br>
    <input type="text" id="security_pin" name="security_pin"><br>
    <label for="new_password">Nueva contraseña:</label><br>
    <input type="password" id="new_password" name="new_password"><br><br>
    <input type="submit" value="Cambiar contraseña">
  </form>
</body>
</html>
