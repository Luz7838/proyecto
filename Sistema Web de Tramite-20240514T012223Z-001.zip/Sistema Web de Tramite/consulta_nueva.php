<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="estilo.css">
    
</head>
<body>
    <div class="general">
    <div class="contenedor_general">
        <div class="busqueda">
            <h2>Consulta de trámite</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="codigo_o_correo">Código de trámite o Correo Electrónico:</label>
            <div class="boton">
            <input type="text" id="codigo_o_correo" name="codigo_o_correo">
            <button type="submit"><i class="bi bi-search"></i></button>
            </div>
            </form>
        </div>
        <div class="contenedor_informacion2">
            <div class="titulo_informacion2">
            <h2>DETALLE DE TRAMITE</h2>
            <img src="./logo.png" alt="">
            </div>
            <div class="info2">
                <div class="info_p1">
                <?php
            // Conexión a la base de datos y lógica de consulta existente
            $servername = "localhost";
            $username = "root";
            $password = "12345678";
            $dbname = "sistemawebtramite";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Conexión fallida: " . $conn->connect_error);
            }

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $codigo_o_correo = $_POST['codigo_o_correo'];

                $sql = "SELECT codigo_tramite, nombre, fecha_envio, fecha_atencion, estado, correo, Mensaje, id FROM tu_tabla WHERE codigo_tramite = '$codigo_o_correo' OR correo = '$codigo_o_correo'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {

                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>Codigo de Tramite:</p></div>
                        <div class='datos'><p>". $row["codigo_tramite"] . "</p></div>";
                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>Nombres y Apellidos:</p></div>
                        <div class='datos'><p>". $row["nombre"] . "</p></div>";
                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>DNI:</p></div>
                        <div class='datos'><p>". $row["nombre"] . "</p></div>";
                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>Domicilio:</p></div>
                        <div class='datos'><p>". $row["nombre"] . "</p></div>";
                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>Correo Electronico:</p></div>
                        <div class='datos'><p>". $row["correo"] . "</p></div>";
                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>Telefono/Celular:</p></div>
                        <div class='datos'><p>". $row["celular"] . "</p></div>";
                        echo "</div>";
                        echo "<div class='info_p2'>";
                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>Estado:</p></div>
                        <div class='datos'><p>". $row["estado"] . "</p></div>";
                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>Fecha de envio:</p></div>
                        <div class='datos'><p>". $row["fecha_envio"] . "</p></div>";
                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>Fecha de atencion:</p></div>
                        <div class='datos'><p>". $row["fecha_atencion"] . "</p></div>";
                        echo "<div class='detalle'><i class='bi bi-check-circle-fill'></i><p>Asunto:</p></div>
                        <div class='datos'><p>". $row["estado"] . "</p></div>";


                    }
                } else {
                    echo "<tr><td colspan='7'>No se encontraron resultados para el código de trámite o correo electrónico proporcionado.</td></tr>";
                }
                echo "<tbody>";
                echo "</table>";
                $conn->close();
            }
        ?>
                    
                    <div class="detalle"><i class="bi bi-check-circle-fill"></i><p>PDF:</p></div>
                    <div class="pdf"><a href="">fut_antoño_muñoz.pdf<i class="bi bi-filetype-pdf"></i></a></div>
                    <button>Reenviar PDF</button>
                </div>
            </div>
        </div>    
    </div>
    
</body>
</html>